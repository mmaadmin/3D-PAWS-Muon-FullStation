Selected files from the DigitalIO library.

https://github.com/greiman/DigitalIO